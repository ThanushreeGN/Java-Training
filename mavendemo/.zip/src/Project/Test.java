package Project;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		String name="Thanu",technology="Java";
		int age=21;
		
	
	System.out.println("Details......... ");
	System.out.println("My name is "+name);
	System.out.println("My age is  "+age);
	System.out.println("I am learning "+technology);

}
}