package Project;

public class simpleInterst {
	public static void main(String[] args) {
float p,r,t,si;
p=2000;
r=12;
t=2;
si=(p*r*t)/100;
System.out.println("Simple Interst is: " +si);
}
}
